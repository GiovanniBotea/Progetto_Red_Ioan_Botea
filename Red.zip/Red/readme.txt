Color: darkred, #C67F7F, #ececec

Font:  Nova Square, Rajdhani